import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-thread-plist-routed',
  templateUrl: './admin-thread-plist-routed.component.html',
  styleUrls: ['./admin-thread-plist-routed.component.css']
})
export class AdminThreadPlistRoutedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
