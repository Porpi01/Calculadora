import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-user-new-routed',
  templateUrl: './admin-user-new-routed.component.html',
  styleUrls: ['./admin-user-new-routed.component.css']
})
export class AdminUserNewRoutedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
