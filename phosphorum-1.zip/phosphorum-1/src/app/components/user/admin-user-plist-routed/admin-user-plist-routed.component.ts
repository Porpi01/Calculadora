import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-user-plist-routed',
  templateUrl: './admin-user-plist-routed.component.html',
  styleUrls: ['./admin-user-plist-routed.component.css']
})
export class AdminUserPlistRoutedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
