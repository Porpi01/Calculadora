import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { PaginatorState } from 'primeng/paginator';
import { IUser, IUserPage } from 'src/app/model/model.interfaces';
import { AdminUserDetailUnroutedComponent } from '../admin-user-detail-unrouted/admin-user-detail-unrouted.component';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-admin-user-plist-unrouted',
  templateUrl: './admin-user-plist-unrouted.component.html',
  styleUrls: ['./admin-user-plist-unrouted.component.css'],
  providers: [ConfirmationService]
})
export class AdminUserPlistUnroutedComponent implements OnInit {
  oPage: any = [];
  orderField: string = 'id';
  orderDirection: string = 'asc';
  oPaginatorState: PaginatorState = { first: 0, rows: 10, page: 0, pageCount: 0 };
  status: HttpErrorResponse | null = null;

  constructor(
    private oHttpClient: HttpClient,
    public dialogService: DialogService,
    public messageService: MessageService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit() {
    this.getPage();
  }

  getPage(): void {
    this.oHttpClient
      .get<IUserPage>(
        'http://localhost:8085/user' +
          '?size=' +
          this.oPaginatorState.rows +
          '&page=' +
          this.oPaginatorState.page +
          '&sort=' +
          this.orderField +
          ',' +
          this.orderDirection
      )
      .subscribe({
        next: (data: IUserPage) => {
          this.oPage = data;
          this.oPaginatorState.pageCount = data.totalPages;
          console.log(this.oPaginatorState);
        },
        error: (error: HttpErrorResponse) => {
          this.oPage.error = error;
          this.status = error;
        }
      });
  }

  onPageChang(event: PaginatorState) {
    this.oPaginatorState.rows = event.rows;
    this.oPaginatorState.page = event.page;
    this.getPage();
  }

  doOrder(fieldorder: string) {
    this.orderField = fieldorder;
    if (this.orderDirection == 'asc') {
      this.orderDirection = 'desc';
    } else {
      this.orderDirection = 'asc';
    }
    this.getPage();
  }

  ref: DynamicDialogRef | undefined;

  goToView(u: IUser) {
    this.ref = this.dialogService.open(AdminUserDetailUnroutedComponent, {
      data: {
        id: u.id
      },
      header: 'View of user',
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 10000,
      maximizable: false
    });
  }

  deleteUser(userId: number) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete this user?',
      accept: () => {
        this.oHttpClient.delete(`http://localhost:8085/user/${userId}`).subscribe(
          () => {
            console.log('User deleted successfully');
            this.getPage();
          },
          (error: HttpErrorResponse) => {
            console.error('Error deleting user', error);
          }
        );
      }
    });
    
  }
  confirmDelete(userId: number) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete this user?',
      accept: () => {
        // Esta función se ejecutará si el usuario confirma la eliminación
        this.deleteUser(userId);
      },
      reject: () => {
        // Esta función se ejecutará si el usuario cancela la eliminación
      }
    });
}
}