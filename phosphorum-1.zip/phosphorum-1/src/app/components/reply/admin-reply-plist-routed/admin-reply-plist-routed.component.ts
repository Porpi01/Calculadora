import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-reply-plist-routed',
  templateUrl: './admin-reply-plist-routed.component.html',
  styleUrls: ['./admin-reply-plist-routed.component.css']
})
export class AdminReplyPlistRoutedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
