package net.ausiasmarch.operbase.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import net.ausiasmarch.operbase.entity.OperacionEntity;
import net.ausiasmarch.operbase.repository.OperacionRepository;

@RestController
@RequestMapping("/calc")
public class OperacionController {

    @Autowired
    OperacionRepository operacionRepository;

    @GetMapping("/{id}")
    public ResponseEntity<OperacionEntity> get(@PathVariable Long id) {        
        OperacionEntity operacion = operacionRepository.findById(id).orElse(null);
        if (operacion == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(operacion);        
    }

 @PostMapping()
public ResponseEntity<ApiResponse<OperacionEntity>> create(@RequestBody OperacionRequest operacionRequest) {  
    ApiResponse<OperacionEntity> response = new ApiResponse<>();
    try {
        // Obtener operandos y operación del objeto OperacionRequest
        double operando1 = operacionRequest.getOperando1();
        double operando2 = operacionRequest.getOperando2();
        String operacion = operacionRequest.getOperacion();
        
        double resultado = 0.0;
        String simbolo = "";

        switch (operacion.toLowerCase()) {
            case "sumar":
                resultado = operando1 + operando2;
                simbolo = "+";
                break;
            case "restar":
                resultado = operando1 - operando2;
                simbolo = "-";
                break;
            case "multiplicar":
                resultado = operando1 * operando2;
                simbolo = "*";
                break;
            case "dividir":
                if (operando2 != 0) {
                    resultado = operando1 / operando2;
                    simbolo = "/";
                } else {
                    response.setError("No se puede dividir por cero.");
                    return ResponseEntity.badRequest().body(response);
                }
                break;
            default:
                response.setError("Operación no válida: " + operacion);
                return ResponseEntity.badRequest().body(response);
        }

        // Crear una entidad OperacionEntity con la operación y el resultado
        OperacionEntity operacionEntity = new OperacionEntity();
        operacionEntity.setOperacion(operando1 + " " + simbolo + " " + operando2);
        operacionEntity.setResultado(resultado);

        OperacionEntity savedOperacion = operacionRepository.save(operacionEntity);

        response.setData(savedOperacion);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    } catch (Exception e) {
        response.setError("Error en la operación: " + e.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }
}
}