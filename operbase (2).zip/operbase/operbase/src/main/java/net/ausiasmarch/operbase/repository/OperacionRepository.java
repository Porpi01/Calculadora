package net.ausiasmarch.operbase.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import net.ausiasmarch.operbase.entity.OperacionEntity;

public interface OperacionRepository extends JpaRepository<OperacionEntity, Long>{
    

    
}
