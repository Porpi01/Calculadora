package net.ausiasmarch.operbase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OperbaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(OperbaseApplication.class, args);
	}

}
