package net.ausiasmarch.operbase.api;

public class ApiResponse<T> {
    private T data;
    private String error;

    // Getters y setters

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
